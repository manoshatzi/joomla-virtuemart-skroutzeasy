Joomla v.1.5+ Skroutz Easy module
====================================

## English

### Requirements

 - [Joomla! v.1.5 or v.2.5](http://www.joomla.org)
 - [VirtueMart 2.0.2](http://virtuemart.net)

### Installation instructions

1. Install Joomla! and VirtueMart
2. ...

3. Login to the 'Administration Tool' and enable the 'Extension'
    - Select 'Install / Uninstall' from the 'Extensions' menu
    - Click 'Choose file' and select the extension from your HDD
    - Upload the file using 'Upload File & Install'
    - ...

## Greek

### Απαιτήσεις

 - [Joomla! v.1.5 or v.2.5](http://www.joomla.org)
 - [VirtueMart 2.0.2](http://virtuemart.net)

### Οδηγίες εγκατάστασης

...
